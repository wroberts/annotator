# Description of the aspectually-annotated corpus

This material is distributed with the NAACL 2019 paper "A German
Corpus Annotated for Fundamental Aspectual Class".

The annotated corpus is contained in the file corpus.json, using the
JSON file format.  The file uses the UTF-8 character encoding.  The
object in the file contains two metadata fields, `version` (listing
the date that the corpus was compiled) and `contact` (with an email
address).  The annotated data itself is in a list structure under the
`clauses` key.

Each clause record in `clauses` is an object that defines the
following properties:

- `section`: the section of the corpus the clause belongs to, as
  described in Section 4 of the paper (either `A`, `B`, or `C`)
- `verb`: the lemma of the verb that was annotated
- `sindex`: the index of the sentence in the SDEWAC corpus which
  produced this example
- `orig_windex`: the index of the verb in the sentence that was annotated
- `words`: a list of words in the clause containing the verb to be annotated
- `windex`: the index of the verb that was annotated in the list `words`
- `pwindex`: if available, the index of the verb's separable prefix in
  the list `words`
- `verbfreq`: a code indicating the frequency of the verb; this code
  is one of high `H` (meaning a count of more than 10^5 in SDEWAC),
  medium `M` (count > 10^4), low `L` (count > 10^3), or very low `VL`
  (count < 10^3)
- `valid`: a flag which is True if neither annotator marked the clause
  as invalid
- `user1` and `user2`: a list of annotations made by the two
  annotators
- `ambclass`: a string representing the ambiguity class of the token,
  as used in our 6-way classification task
  
Annotations are indicated as five-character strings, representing the
five categories explicitly annotated.  Each category may be positive,
negative, or ambiguous/unknown (indicated with a `?`).  The five
categories are:

1. Invalid (`I`), valid (`i`), or ambiguous (`?`);
2. Stative (`S`), dynamic (`s`), or ambiguous (`?`);
3. Bounded (`B`), unbounded (`b`), or ambiguous (`?`);
4. Extended (`E`), punctual (`e`), or ambiguous (`?`);
5. Change-of-state (`C`), no change-of-state (`c`), or ambiguous (`?`).

Thus, an annotation of `isBEC` indicates a verb that was annotated as
valid, dynamic, bounded, extended, and with a change-of-state, while
`iSbEc` indicates a verb that was marked as valid and stative.

Further, each object defines several automatically-computed features
that might be useful for building a supervised classifier:

- `aux`: always False
- `clause_type`: if the verb is contained in a subordinate clause,
  this field indicates the type of subordination used; codes are based
  on the subcategorisation frame inventory defined by Schulte im
  Walde (2002).
- `finite`: a Boolean value indicating if the verb is finite (tensed)
  or not
- `has_nicht`: always False
- `imperative`: always False
- `infinite`: a Boolean value indicating if the verb is infinitival or
  not
- `mod`: always False
- `passive`: a Boolean value indicating if the verb is used in a
  passive construction
- `pos`: the part of speech tag of the verb
- `scf`: a code representing the verb's subcategorisation frame, as
  described in Roberts et al. (2014).
- `tense`: the tense of the verb (`pres`, `past`, or `fut`)
- `tform`: the form of the verb's tense (`simple` or `aux`)
- `aspinds`: aspectually-relevant concomitants to the verb, composed
  of a type, and two indices into the words list to indicate where the
  relevant constituent is)
- `synargs`: syntactic concomitants to the verb, composed of a type,
  and two indices into the words list to indicate where the relevant
  constituent is)

## References:

1. Roberts, W., Egg, M., & Kordoni, V. (2014). Subcategorisation
   acquisition from raw text for a free word-order language. In
   Proceedings of the 14th Conference of the European Chapter of the
   Association for Computational Linguistics
   (pp. 298–307). Gothenburg, Sweden: Association for Computational
   Linguistics.
2. Schulte im Walde, S. (2002). A subcategorisation lexicon for German
   verbs induced from a lexicalised PCFG. In Proceedings of the 3rd
   Conference on Language Resources and Evaluation (LREC)
   (pp. 1351–1357).
