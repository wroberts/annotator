# Aspectual Annotation Guidelines

## 1.    Introduction

"Aspect" characterises the way in which the temporal progression of a state of affairs or *eventuality* is described (e.g., does it involve change, temporal boundaries, is it extended or punctual). Depending on differences in this description, verbs (sometimes only verbs together with specific arguments) can be grouped into a number of aspectual classes. It is the goal of the present annotation initiative to manually produce a database that offers such a classification.

You will be given a set of automatically segmented and parsed German sentences, whose main verb has been marked. It is your task now to annotate this verb token for its aspectual class in the context of the sentence. 

In this initiative, we define the aspectual class of a verb by choosing one option each in four aspectual dichotomies, which are described in  detail in Section 2. 

-    stative/dynamic
-    bounded/unbounded
-    change/no change
-    punctual/durative


Sentences may also be classified as invalid, if they are unsuitable for the task of aspectual classification.

Our goal is annotating verb tokens in their respective context, not annotating the clauses or sentences they are part of. The reason for this is that clauses and sentences can additionally contain aspectually relevant phenomena (like durative or frequency adverbials) that can exert aspectual influence in that they can map the aspectual class of the verb onto a new aspectual class for the constituent comprising them and the verb. 

We will explicate the exact procedure of getting this right below in Section 3. This includes an account of verbs for which a specific argument is relevant for aspectual classification, e.g., in the case of *eat an apple* (which introduces inherent boundaries) as opposed to *eat apples*, which does not.

Section 4 points out that verbs sometimes change their interpretation if they occur in a context that calls for items of a different aspectual class than their own. In order to avoid a clash, the interpretation of the verb is changed without visible specification. This "coercion" or "reinterpretation" can complicate the annotation.

Annotation takes place with the help of an annotation tool that was specifically developed for this task and is described in Section 5. 



## 2.    Aspectual classes

This section introduces the aspectual dichotomies according to which the aspectual classification takes place. After a short characterisation of the dichotomy, aspectual "tests" will be provided, which help you to make the distinction for a given verb. Such tests take the form of linguistic contexts in which items of a specific aspectual class can or cannot occur. For a list of aspectual tests, see Dowty (1979). Note that these tests are only valid if the meaning of the verb is not coerced in order to fit in with an aspectual restriction of the environment, see Section 4 for details.

Some of the examples used in this section consist of a verb with an argument. These are cases in which a specific argument exerts an aspectual influence, see Section 3 for a detailed account.

### 2.1    Valid - Invalid

This first distinction is not a true aspectual distinction, but since it is part of the annotation, it is grouped here with the aspectual classification.

Whenever you annotate a new sentence, the first choice pertains to the question of whether you are dealing with an item that can reasonably be classified aspectually. Because the pre-processing of the annotation corpus has been done automatically, the corpus may contain items that are not appropriate to the primary task. In these cases, the verb should be tagged as invalid. Examples include:

* Mis-tagged verbs, in particular, auxiliaries (which are excluded from the annotation task, but might show up nevertheless in the annotation task because they have been falsely classified as a main verb), or verbs with separable prefixes where the prefix has not been recognised as being part of the verb);

* Sentence fragments, where complements to a verb needed for the assessment of lexical aspect are not shown (see Section 3), and it is not even possible to define the range of possibilities;

* Fragmentary expressions in which the exact meaning of the verb cannot be ascertained, including cases in which the verb itself is missing.


### 2.2    Stative - Dynamic

Stative verbs describe a static situation without any change, e.g., *mögen* 'like', whereas dynamic verbs introduce eventualies with some change (e.g., continuous change of position in *move*). Stative verbs express that a property obtains at a particular point or interval in time. They do not refer to eventualities with inherent boundaries, or to eventualities like processes or events that can "happen". 

Stative verbs are frequently incompatible with the imperative mood.

* *Geh nach Hause!* 'Go home!'

* ?? *Wisse die Antwort!* 'Know the answer!'

Stative verbs cannot be the complement of the verb *zwingen* ‘to force’ or occur in combination with adverbials expressing intentionality like *freiwillig* ‘voluntarily’:

* *Ich habe sie gezwungen, nach Hause zu gehen.* 'I forced her to go home.'

* ?? *Ich habe sie gezwungen, die Antwort zu wissen.* 'I forced her to know the answer.'

* ?? *Er weiß die Antwort freiwillig.* 'He knows the answer voluntarily.'

* *Er geht freiwillig nach Hause.* 'He is going home voluntarily.'

Also, if the validity of a verb for a specific temporal interval entails its validity for every instant within this interval, we are dealing with a stative verb, e.g. *beam*. This is different for dynamic verbs like *walk*, so, if John beamed from 8-9am, he also beamed at 8.30pm sharp, but if he walked from 8-9am, we cannot claim that he walked at 8.30 sharp, because walking eventualities have a certain minimal size (1-2 steps).

Note that one of the most prominent tests to distinguish dynamic from stative verbs, viz., the progressive, is not available for German.


### 2.3    Unbounded - Bounded 

Dynamic verbs can be unbounded, i.e., introduce eventualities without inherent boundaries, e.g., *move* or *play the piano*, or bounded, i.e., refer to eventualities with such boundaries, e.g., *run a mile* or *build a house*. Eventualities with boundaries have a natural conclusion, a point in time at which the expressed action is finished and cannot continue any longer. Eventualities without these boundaries cannot be finished in this way, they can only be stopped.

Boundedness of a verb can usually be determined by combining it with a time frame adverbial like *in zwei Stunden* 'in two hours' that express the (maximal) amount of time required to finish the action. Conseqently, unbounded items like *Klavier spielen* 'play the piano' are not compatible with these adverbials:

* *?? Ich habe in fünfzehn Minuten Klavier gespielt*. 'I played the piano in 15 minutes.'
* *Ich habe  in fünfzehn Minuten die Sonate gespielt.* 'I played the sonata in 15 minutes.'

The combination with durative adverbials like *zwei Stunden (lang)* 'for two hours' has exactly the opposite effect. Since such adverbials introduce boundaries themselves, they are only compatible with unbounded, but not with bounded items: 

* *Ich habe fünfzehn Minuten (lang) Klavier gespielt*. 'I played the piano for 15 minutes.'
* *?? Ich habe fünfzehn Minuten (lang) die Sonate gespielt.* 'I played the sonata for 15 minutes.'



### 2.4    Punctual - Durative

Events may be considered to take a particular amount of time, or they may be conceived of as happening (relatively) instantaneously. To distinguish punctual and durative bounded verbs, we can use adverbials like *plötzlich* 'suddenly' or time point PPs like *um 11 Uhr* 'at 11 o'clock', which are only compatible with the first group:

* *Er hat plötzlich/um 11 Uhr gehustet.* 'He coughed suddenly/at 11 o'clock.'

* *?? Er hat plötzlich/um 11 Uhr ein Haus gebaut.* 'He built a house suddenly/at 11 o'clock.'

Similarly, time frame adverbials can only measure the duration of eventualities denoted by durative verbs like *ein Haus bauen*  'build a house' but not of punctual verbs like *husten* 'cough'.

* *Er baute in drei Monaten ein Haus.* 'He built a house in three months.'
* *?? Er hustete in einer Sekunde.* 'He coughed in one second.'


### 2.5    Change - No change

Change verbs lexically express a specific change of state in their semantics, e.g., *sterben*  'die' expresses a change from being alive to being dead. I.e., they characterise both the situation immediately before the eventualities they refer to (the "prestate") as well as the situation immediately afterwards (the "poststate").

This is in contrast with bounded verbs that introduce an eventuality with inherent boundaries but no explicit change of state, e.g., *husten* 'cough' or *eine Meile laufen* 'run a mile'. They merely indicate that a specific activity lasted for a certain amount of time (extended or punctual), without characterising pre- and poststate.

Verbs of change (especially those denoting an externally caused change) often permit an alternation between the causative and the inchoative:

* *Das Fenster zerbrach.* 'The window broke.'

* *Johann zerbrach das Fenster.* 'Johann broke the window.'

Changes of state may involve the change of location or possession of a patient argument.

* *Ich schenkte meiner Mutter die Rosen.* 'I gave my mother the roses.'

* *Sie holte einen Rechen aus dem Geräteschuppen.* 'I fetched a rake from the garden shed.'

The change introduced by the verb may be temporary or permanent, and may vary between borderline changes of state which alter an entity superficially to events which result in the creation or destruction of an entity.

* *Ich errötete.* 'I blushed.'

* *Ich wischte mir die Stirn ab.* 'I wiped my forehead.'

* *Ich öffnete die Tür.* 'I opened the door.'

* *Ich habe das Buch geschrieben/den Kuchen gebacken.* 'I wrote the book / baked the cake.'

* *Ich habe den Brief verbrannt.* 'I burned the letter.'

The standard test for change verbs in English is the perfect tense, however, since the perfect in German is gradually taking over the role of the imperfective, it is no longer a reliable test for aspectual class in German. Still, we can simulate the effect of this test by combining the perfect with *gerade eben* 'just now':

* *Max ist gerade eben angekommen.* 'Max has arrived just now.'

* *Max ist gerade eben gelaufen.* 'Max has run just now.'

* *Max hat gerade eben gehustet.* 'Max has coughed just now.'

If such a sentence entails information on the moment of utterance, we are dealing with a change verb. While it is possible in German to combine the perfect plus *gerade eben* with no-change verbs like *husten* 'cough' or *laufen* 'run', too, this does not entail anything about the moment of utterance. This is in contrast to the first example, which entails that at the moment of utterance, Max is present, because *ankommen* 'arrive' introduces a change of state from being away to being present.

Another aspectual test for change verbs uses *fast* 'almost'. The combination of change verbs with *fast* leads to ambiguity, e.g., for *fast sterben* 'almost die': 

* *John starb fast* 'John almost died.'

In the first reading, John came close to undergoing a change from being alive to being dead, but, in fact, nothing happened; in the second reading, he did undergo a change, from being alive to being close to dead. No such ambiguity would arise for *fast husten* 'almost cough', which only has the reading that one came close to coughing, but that, eventually, nothing happened.



## 3.    Marking "verbs in context"
  
In the preceding section, the examples sometimes involved not only verbs, but an additional argument. The reason for this is that in some cases, the verb in isolation is not sufficient for aspectual classification.

The temporal progression of an eventuality is primarily characterised by a verb. While in many cases the verb already determines this progression, and hence can be classified aspectually in isolation, specific arguments of a verb can also influence the aspectual class, especially if it refers to an entity that is affected or changed by the eventuality introduced by the verb gradually. If so, this argument is important for the verb's aspectual classification and must be taken into consideration for the annotation.

In particular, this holds for so-called "incremental themes" in verbs like *essen* 'eat' or *bauen* 'build' (Krifka 1992). The idea is that the object referents undergo the process of eating or building gradually, hence, any boundaries that the objects introduce carry over to the eventuality itself: For instance, eating an apple will inevitably reach the stage at which the last bit of the apple has been consumed, at which moment the eventuality necessarily stops. The resulting classification for *einen Apfel essen* 'eat an apple' is extended and change.

No such boundaries are introduced by *Äpfel essen* 'eat apples', because the object *Äpfel* itself introduces no such boundaries. Hence, it classifies as dynamic and unbounded.

Note that such incremental themes can be of a more abstract nature, which shows up for *eine Sonate spielen* 'play a sonata' vs. *Sonaten spielen* 'play sonatas' as well as for *eine Meile laufen* 'walk a mile' vs. *ein paar Meter laufen* 'walk a few metres'. Here the pieces of music and the traversed paths are the gradually processed entities. Again, if they introduce boundaries, these are inherited by the verb as well. The resulting class in these cases would be extended no-change, because neither *eine Sonate spielen* nor *eine Meile laufen* introduce a change of state. 

In combination with objects that introduce no boundaries like in *Sonaten spielen* and *ein paar Meter laufen*, the verbs qualify as dynamic and unbounded.

At this point, it is necessary to distinguish this effect, which is obligatory, from similar phenomena, which are only optional, like in the following example.

* *Stundenlang kamen Gäste an.* 'For hours, guests arrived.'

Although we have classified *ankommen* 'arrive' as a punctual change verb, which due to its boundedness should not be compatible with durative adverbials like *stundenlang* 'for hours', its argument seems to exert the same kind of influence that we have seen for incremental arguments: If the guests arrived one after the other, and the number is not limited, this unboundedness seems to be inherited by the verb, which then licenses compatibility with the durative adverbial.

However, the marked difference between this case and true gradual arguments is its optionality. Compare:

* *Plötzlich kamen Gäste an.* 'Suddenly, guests arrived.'
* *?? Plötzlich aß er einen Apfel.* 'Suddenly, he ate an apple.'

The first sentence is fully acceptable (in the sense that the guests arrived as one group), while the second one can only be understood very marginally (if at all) in a non-literal sense (that the beginning of the eating was immediate and unexpected). Such non-literal interpretations, however, are due to the additional process of coercion (see the next section), hence, show that an aspectual selection restriction is violated. In other words, the verb in the first sentence is punctual, because it can be combined with *plötzlich*, while the second verb is not. The fact that *ankommen* in combination with a bare plural can be understood in an unbounded way is due to a secondary optional process of iteration. 

The annotation should only include the effect of verb arguments if they are mandatory like in the case of *essen* or *spielen*, and ignore optionally influencing arguments like for *ankommen*. 


## 4.    Aspectual coercion or reinterpretation

Sometimes a verb is "coerced" or "reinterpreted" to fit aspectual requirements of the operator. E.g., the English progressive requires non-stative and extended predicates, still the stative *be silly* and the punctual *cough* can occur in the progressive, after being coerced into unbounded predicates ('act in a silly way' and 'cough repeatedly', respectively). For a list of such coercion patterns, see Moens & Steedman (1988). 

A typical kind of coercion applies to punctual no-change verbs like *husten* 'cough' or *klopfen* 'knock': If they are combined with a durative adverbial (which requires an unbounded verb), an iterative operator can intervene, which changes the interpretation of the verb into 'performing a whole series of eventualities of the kind denoted by the literal meaning of the verb'. Such an iteration is unbounded and hence compatible with the adverbial. 

Similarly, the combination of extended verbs with adverbials like *plötzlich* 'suddenly' that require a punctual verb can cause inchoative reinterpretation of the verb (because the beginning of an extended eventuality is only a moment of time). For instance, *plötzlich rennen* 'suddenly run' refers to the start of a running that happens quickly and unexpectedly.

The effect of such coercions should not be reflected in the annotation, which strives at recording the original aspectual class, the one that obtained before reinterpretation took place.


## 5.    The annotation tool

The tool is to be found online under https://github.com/wroberts/annotator. When you start the annotation work, you need to register and create a new account. Each sentence is presented for annotation on a page of its own. You can go backward and forward, e.g., in order to compare or change previous annotations. The database is searchable for individual verbs or text in general. Note that you first indicate the material to be searched, then you can move to sentences comprising this material by clicking "Previous clause" or "Next clause".

You will find that the choices that you make are interdependent, for instance, if you classify a verb as unbounded, it will automatically also be classified as dynamic. These dependencies are motivated by the underlying aspectual theory and safeguard that erroneous combinations of aspectual features are ruled out automatically (e.g., stative and bounded would not be possible to annotate).

The tool allows you to model aspectual ambiguity in two ways. First, you can assign several full aspectual annotations by clicking the "New annotation" button at the bottom of the page. This is a phenomenon that can be quite systematic, e.g., many verbs in the semantic field of communication  like *zeigen* 'show' or *beweisen* 'prove' have a stative reading, here, 'be a logical implicature for' and simultaneously an extended change reading, here, 'perform a logical deduction'. Similarly, so-called "degree achievements" like *den Weg kehren* 'sweep the path' have both an unbounded reading (continuous development, here, towards cleanliness) and an extended change reading (here, crossing a threshold of cleanliness). 

Second, in between the two elements in a feature pair there is a question mark, which you can use in case you feel unable to select one of them. 

### References

David Dowty. 1979. *Word meaning and Montague grammar*. Dordrecht: Reidel.

Manfred Krifka. 1992. Thematic roles as links between nominal reference and temporal constitution. In Ivan Sag and Anna Sabolcsi, editors, *Lexical matters*, pages 29–53. CSLI, Stanford.

Marc Moens and Mark Steedman. 1988. Temporal ontology and temporal reference. *Computational Linguistics*, 14(2):15–28.
